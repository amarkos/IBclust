## Submission 1.2
* Added Agglomerative IB.
* Added Generalised IB.
* Added standard IB.