## Submission 1.1
* Created vignette for package.